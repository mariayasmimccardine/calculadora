#include <stdio.h>
#include <stdlib.h>

char digitToHex(int digit) {
    return digit < 10 ? digit + '0' : digit - 10 + 'A';
}

void decimalParaBase(int num, int base, char baseStr) {
    intdigits = (int )malloc(sizeof(int) 32);
    int i = 0;

    while (num > 0) {
        digits[i++] = num % base;
        num /= base;
    }

    printf("Conversão para %s:\n", baseStr);
    printf("Passos:\n");
    for (int j = i - 1; j >= 0; j--) {
        if (base == 16) {
            printf("%c ", digitToHex(digits[j]));
        } else {
            printf("%d ", digits[j]);
        }
    }
    printf("\n");

    free(digits);
}

void decimalParaBCD(int num) {
    printf("Conversão para BCD:\n");
    printf("Passos:\n");

    while (num > 0) {
        int digit = num % 10;
        num /= 10;

        for (int i = 3; i >= 0; i--) {
            printf("%d", (digit >> i) & 1);
        }
        printf(" ");
    }
    printf("\n");
}

int main() {
    int numero;

    printf("Digite um número em base 10: ");
    scanf("%d", &numero);

    decimalParaBase(numero, 2, "Binário");
    decimalParaBase(numero, 8, "Octal");
    decimalParaBase(numero, 16, "Hexadecimal");
    decimalParaBCD(numero);

    return 0;
} 